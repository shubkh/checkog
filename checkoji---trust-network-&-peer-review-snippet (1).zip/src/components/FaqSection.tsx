import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface FaqItem {
  question: string;
  answer: string;
}

const faqs: FaqItem[] = [
  {
    question: 'How does OG match contacts between people without invading privacy?',
    answer:
      'OG uses a strict mutual-contact rule. A contact is only matched if both individuals have each other saved in their phone books (just like WhatsApp or Truecaller mutual matching). If someone is in your contacts but hasn’t saved you, they will never be matched. Furthermore, contact data is salted and hashed client-side — neither OG nor the merchant can view, export, or spam your contacts.',
  },
  {
    question: 'What is the pricing model for website owners and merchants?',
    answer:
      'Pricing is simple and strictly pay-per-value: ₹2 every time a customer clicks the snippet and at least one mutual contact (named or anonymous) is found. If no one in their contacts is using the product or service, you are charged ₹0. There are no monthly recurring subscriptions, platform retainers, or hidden fees.',
  },
  {
    question: 'Can reviewers choose to stay anonymous?',
    answer:
      'Yes, absolutely. When purchasing or reviewing, customers can toggle "Stay Anonymous". In that case, mutual contacts will see "Anonymous contact in your phonebook". Furthermore, a prospective buyer can click "Ask to unmask", which sends a private notification allowing the reviewer to decide whether to reveal their identity.',
  },
  {
    question: 'How do users give contact access without friction?',
    answer:
      'Users grant a 1-time mutual contact sync via mobile OTP or Google Contacts session (similar to WhatsApp or Truecaller onboarding). Once authenticated, they immediately see mutual recommendations.',
  },
  {
    question: 'Which platforms does OG support?',
    answer:
      'OG works on all websites including Shopify, WooCommerce, Webflow, Squarespace, React/Next.js, and custom HTML/PHP. You simply paste our 1-line async script tag next to your existing reviews.',
  },
];

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="py-20 px-4 sm:px-6 max-w-3xl mx-auto border-t border-stone-200">
      <div className="text-center mb-12">
        <span className="text-xs font-bold text-stone-500 uppercase tracking-widest block mb-2">
          FAQ
        </span>
        <h2 className="text-3xl sm:text-4xl font-black text-[#141413] tracking-tight">
          Frequently Asked Questions
        </h2>
      </div>

      <div className="space-y-3">
        {faqs.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className="rounded-2xl bg-white border border-stone-300/80 shadow-sm overflow-hidden transition"
            >
              <button
                onClick={() => setOpenIndex(isOpen ? null : idx)}
                className="w-full px-5 py-4 text-left flex items-center justify-between gap-4 font-bold text-sm sm:text-base text-stone-900 hover:text-emerald-800 transition"
              >
                <span>{faq.question}</span>
                <ChevronDown
                  className={`w-4 h-4 text-stone-500 shrink-0 transition-transform duration-200 ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-stone-600 leading-relaxed border-t border-stone-100">
                  {faq.answer}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
