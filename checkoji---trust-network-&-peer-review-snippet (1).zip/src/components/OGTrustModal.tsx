import React, { useState } from 'react';
import { 
  X, Check, Lock, Smartphone, Send, Star, ShieldCheck, 
  Sparkles, CheckCircle2, User, UserX, AlertCircle, ArrowRight,
  Cookie, Info, ChevronDown, ChevronUp, RotateCcw
} from 'lucide-react';
import { BusinessItem, ContactPeer } from '../types';
import { DEMO_PHONE, DEMO_OTP } from '../data/mockData';

interface OGTrustModalProps {
  isOpen: boolean;
  onClose: () => void;
  business: BusinessItem;
}

export const OGTrustModal: React.FC<OGTrustModalProps> = ({
  isOpen,
  onClose,
  business,
}) => {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [cookieAvailable, setCookieAvailable] = useState(true);
  const [phoneNumber, setPhoneNumber] = useState(DEMO_PHONE);
  const [otpSent, setOtpSent] = useState(false);
  const [otpInput, setOtpInput] = useState(['', '', '', '']);
  const [revealRequests, setRevealRequests] = useState<Record<string, boolean>>({});
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showPrivacyBrief, setShowPrivacyBrief] = useState(false); // Default folded as requested

  if (!isOpen) return null;

  const handleAcceptCookieSync = () => {
    setIsUnlocked(true);
    setToastMessage('Verified via 1-click cookie consent.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setOtpSent(true);
  };

  const handleOtpChange = (index: number, val: string) => {
    if (val.length > 1) val = val[val.length - 1];
    const newArr = [...otpInput];
    newArr[index] = val;
    setOtpInput(newArr);

    if (val && index < 3) {
      document.getElementById(`modal-otp-${index + 1}`)?.focus();
    }

    if (newArr.every(x => x !== '')) {
      setIsUnlocked(true);
      setToastMessage('Phone verified.');
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  const handleQuickOtpVerify = () => {
    setOtpSent(true);
    setOtpInput(['4', '9', '2', '1']);
    setTimeout(() => {
      setIsUnlocked(true);
      setToastMessage('Verified with demo code 4921.');
      setTimeout(() => setToastMessage(null), 3000);
    }, 350);
  };

  const handleRequestReveal = (contactId: string) => {
    setRevealRequests(prev => ({ ...prev, [contactId]: true }));
    setToastMessage('Unmask request sent to reviewer.');
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleResetDemo = () => {
    setIsUnlocked(false);
    setOtpSent(false);
    setOtpInput(['', '', '', '']);
    setRevealRequests({});
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header - Removed OG logo as requested */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-stone-200 bg-[#FAF9F5]">
          <div>
            <div className="text-xs font-bold text-stone-900 tracking-tight">
              Check OG
            </div>
            <p className="text-[11px] text-stone-500 truncate max-w-[220px]">
              {business.title}
            </p>
          </div>

          <div className="flex items-center gap-2">
            {isUnlocked && (
              <button
                onClick={handleResetDemo}
                className="text-[11px] px-2 py-1 rounded text-stone-500 hover:text-stone-800 hover:bg-stone-100 transition flex items-center gap-1"
                title="Reset verification state"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-3.5">
          {!isUnlocked ? (
            /* UNLOCKED: Super clean, minimal layout */
            <div className="space-y-3.5">
              <div className="text-center pb-1">
                <h4 className="text-sm sm:text-base font-extrabold text-stone-900">
                  Who in your contacts uses this?
                </h4>
              </div>

              {/* 1. TOP: SUPER SMALL 1-CLICK COOKIE CONSENT BUTTON */}
              <div className="p-3 rounded-xl border border-stone-200 bg-[#FAF9F5] flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0">
                    <Cookie className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-stone-900 block">
                      1-Click Cookie Consent
                    </span>
                    <span className="text-[10px] text-stone-500 block">
                      Instant session sync &bull; zero typing
                    </span>
                  </div>
                </div>

                <button
                  onClick={handleAcceptCookieSync}
                  className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition shadow-xs cursor-pointer shrink-0"
                >
                  Verify
                </button>
              </div>

              {/* DIVIDER */}
              <div className="relative flex items-center justify-center my-1">
                <div className="border-t border-stone-200 w-full"></div>
                <span className="bg-white px-3 text-[10px] font-bold text-stone-400 uppercase tracking-wider relative">
                  Or
                </span>
              </div>

              {/* 2. BELOW: VERIFY VIA MOBILE OTP */}
              <div className="p-3.5 rounded-xl border border-stone-200 bg-white space-y-2.5">
                <div className="flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5 text-stone-700" />
                  <span className="text-xs font-bold text-stone-900">
                    Verify via Mobile
                  </span>
                </div>

                {!otpSent ? (
                  <form onSubmit={handleSendOtp} className="space-y-2">
                    <input
                      type="text"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="+91 98200 00000"
                      required
                      className="w-full bg-[#FAF9F5] border border-stone-200 rounded-lg px-3 py-1.5 text-xs text-stone-900 focus:outline-none focus:border-stone-900"
                    />

                    <div className="flex gap-2">
                      <button
                        type="submit"
                        className="flex-1 py-1.5 rounded-lg bg-[#141413] hover:bg-stone-800 text-white font-bold text-xs transition cursor-pointer"
                      >
                        Send Code
                      </button>

                      <button
                        type="button"
                        onClick={handleQuickOtpVerify}
                        className="py-1.5 px-3 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-xs transition cursor-pointer"
                      >
                        ⚡ 1-Tap ({DEMO_OTP})
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="space-y-2.5">
                    <div className="p-1.5 rounded bg-emerald-50 text-[11px] text-emerald-900 flex justify-between items-center border border-emerald-200">
                      <span>Code:</span>
                      <span className="font-mono font-bold bg-emerald-100 px-2 py-0.5 rounded text-emerald-800">
                        {DEMO_OTP}
                      </span>
                    </div>

                    <div className="flex justify-center gap-2">
                      {[0, 1, 2, 3].map((idx) => (
                        <input
                          key={idx}
                          id={`modal-otp-${idx}`}
                          type="text"
                          maxLength={1}
                          value={otpInput[idx]}
                          onChange={(e) => handleOtpChange(idx, e.target.value)}
                          className="w-10 h-10 text-center text-sm font-bold bg-[#FAF9F5] border border-stone-200 rounded-lg text-stone-900 focus:outline-none focus:border-stone-900"
                        />
                      ))}
                    </div>

                    <button
                      type="button"
                      onClick={handleQuickOtpVerify}
                      className="w-full py-1.5 rounded-lg bg-[#141413] hover:bg-stone-800 text-white font-semibold text-xs transition cursor-pointer"
                    >
                      Confirm ({DEMO_OTP})
                    </button>
                  </div>
                )}
              </div>

              {/* 3. PRIVACY & REASSURANCE SECTION: FOLDED BY DEFAULT */}
              <div className="rounded-xl border border-stone-200 bg-[#FAF9F5]/70 overflow-hidden text-xs">
                <button
                  type="button"
                  onClick={() => setShowPrivacyBrief(!showPrivacyBrief)}
                  className="w-full px-3 py-2 flex items-center justify-between font-semibold text-stone-700 hover:bg-stone-100 transition"
                >
                  <div className="flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-stone-500" />
                    <span>How OG protects your privacy</span>
                  </div>
                  {showPrivacyBrief ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>

                {showPrivacyBrief && (
                  <div className="px-3 pb-3 pt-1 text-[11px] text-stone-600 space-y-1.5 border-t border-stone-200/60 bg-white">
                    <div className="flex items-start gap-1.5">
                      <span className="text-emerald-700 font-bold">&bull;</span>
                      <span><strong>Mutual contacts only:</strong> You only see people who saved your number.</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <span className="text-emerald-700 font-bold">&bull;</span>
                      <span><strong>Zero plaintext storage:</strong> Salted SHA-256 hashes protect contact lists.</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <span className="text-emerald-700 font-bold">&bull;</span>
                      <span><strong>Reviewer anonymity:</strong> Reviewers can stay anonymous or unmask on request.</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* WHAT IS INSIDE: THE REVEALED CONTACT LIST (Clean tech-first design) */
            <div className="space-y-3 animate-fade-in">
              <div className="flex items-center justify-between text-xs text-stone-500 pb-1 border-b border-stone-100">
                <span className="font-bold text-stone-900">
                  {business.contacts.length} mutual contacts found
                </span>
                <span className="text-[10px] font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Secure Match
                </span>
              </div>

              {/* Realistic Contact List */}
              <div className="space-y-2">
                {business.contacts.map((contact) => (
                  <div
                    key={contact.id}
                    className="p-3 rounded-xl border border-stone-200 bg-[#FAF9F5] hover:bg-stone-50 transition"
                  >
                    <div className="flex items-start justify-between gap-2.5">
                      <div className="flex items-start gap-2.5">
                        {/* Avatar */}
                        {contact.isAnonymous ? (
                          <div className="w-8 h-8 rounded-full bg-stone-200 text-stone-500 flex items-center justify-center shrink-0 font-bold text-xs">
                            ?
                          </div>
                        ) : (
                          <img
                            src={contact.avatarUrl}
                            alt={contact.name}
                            className="w-8 h-8 rounded-full object-cover shrink-0 ring-1 ring-stone-300"
                          />
                        )}

                        <div>
                          <h4 className="font-bold text-xs text-stone-900">
                            {contact.isAnonymous ? (contact.anonymousLabel || 'Anonymous Contact') : contact.name}
                          </h4>
                          <p className="text-[10px] text-stone-500 mt-0.5">
                            {contact.relationship}
                          </p>
                        </div>
                      </div>

                      {/* Stars */}
                      <div className="flex text-amber-500 text-[10px] shrink-0">
                        {'★'.repeat(contact.rating)}
                      </div>
                    </div>

                    {/* Only show written review if present */}
                    {contact.hasWrittenReview && contact.reviewText ? (
                      <p className="mt-2 text-[11px] text-stone-700 italic bg-white p-2 rounded-lg border border-stone-200">
                        "{contact.reviewText}"
                      </p>
                    ) : (
                      <div className="mt-1.5 text-[10px] text-stone-400 flex items-center gap-1">
                        <Check className="w-3 h-3 text-emerald-600" />
                        <span>Verified purchase</span>
                      </div>
                    )}

                    {/* If Anonymous: Option to "Request to unmask" */}
                    {contact.isAnonymous && (
                      <div className="mt-2 pt-2 border-t border-stone-200 flex items-center justify-between">
                        <span className="text-[10px] text-stone-500">
                          Anonymous review
                        </span>

                        <button
                          onClick={() => handleRequestReveal(contact.id)}
                          disabled={revealRequests[contact.id]}
                          className="text-[10px] font-bold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 px-2 py-0.5 rounded transition disabled:opacity-60 flex items-center gap-1 cursor-pointer"
                        >
                          {revealRequests[contact.id] ? (
                            <>
                              <Check className="w-3 h-3" />
                              <span>Requested</span>
                            </>
                          ) : (
                            <>
                              <span>Ask to unmask</span>
                              <ArrowRight className="w-3 h-3" />
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Toast for reveal request */}
              {toastMessage && (
                <div className="p-2 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>{toastMessage}</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 border-t border-stone-200 bg-[#FAF9F5] flex items-center justify-between text-[11px] text-stone-500">
          <span className="font-mono text-[10px]">Zero storage protocol</span>
          <button
            onClick={onClose}
            className="px-3 py-1 rounded bg-stone-200 hover:bg-stone-300 text-stone-800 font-semibold transition cursor-pointer text-xs"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
