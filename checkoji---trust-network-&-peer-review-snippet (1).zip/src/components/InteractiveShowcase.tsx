import React, { useState } from 'react';
import { motion } from 'motion/react';
import { BUSINESS_ITEMS } from '../data/mockData';
import { BusinessItem } from '../types';
import { OGTrustModal } from './OGTrustModal';
import { PrivacyAssurance } from './PrivacyAssurance';
import { 
  Sparkles, Star, ChevronRight, ShoppingBag, Coffee, 
  CreditCard, Footprints, Check, Users, ArrowUpRight, Hotel, Smartphone
} from 'lucide-react';

export const InteractiveShowcase: React.FC = () => {
  const [selectedId, setSelectedId] = useState<string>('shoe-brand');
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  const currentBusiness: BusinessItem = BUSINESS_ITEMS.find((b) => b.id === selectedId) || BUSINESS_ITEMS[0];

  const getCategoryIcon = (id: string) => {
    switch (id) {
      case 'shoe-brand':
        return <Footprints className="w-3.5 h-3.5" />;
      case 'finance-platform':
        return <CreditCard className="w-3.5 h-3.5" />;
      case 'luxury-resort':
        return <Hotel className="w-3.5 h-3.5" />;
      case 'consumer-app':
        return <Smartphone className="w-3.5 h-3.5" />;
      default:
        return <ShoppingBag className="w-3.5 h-3.5" />;
    }
  };

  return (
    <section id="demo" className="py-20 px-4 sm:px-6 max-w-5xl mx-auto">
      {/* Title */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <span className="text-xs font-bold text-stone-500 uppercase tracking-widest block mb-2">
          Interactive Live Demo
        </span>
        <h2 className="text-3xl sm:text-4xl font-black text-[#141413] tracking-tight">
          See the OG snippet in action.{' '}
          <span className="font-editorial italic font-normal text-stone-600">
            Across verticals.
          </span>
        </h2>
        <p className="mt-3 text-stone-600 text-sm sm:text-base">
          Switch between consumer categories below, then click the OG snippet next to the star ratings to experience the 1-click verification flow.
        </p>
      </div>

      {/* Simulator Container */}
      <div className="bg-white rounded-3xl border border-stone-300/80 shadow-xl overflow-hidden">
        
        {/* Industry Category Switcher */}
        <div className="p-4 sm:p-5 border-b border-stone-200 bg-[#FAF9F5] flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold text-stone-500 uppercase tracking-wider mr-1">
              Select Vertical:
            </span>
            {BUSINESS_ITEMS.map((item) => {
              const active = item.id === selectedId;
              return (
                <button
                  key={item.id}
                  onClick={() => setSelectedId(item.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                    active
                      ? 'bg-[#141413] text-white shadow-sm'
                      : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200'
                  }`}
                >
                  {getCategoryIcon(item.id)}
                  <span>{item.categoryLabel}</span>
                </button>
              );
            })}
          </div>

          <div className="text-xs font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
            <span>Snippet Active</span>
          </div>
        </div>

        {/* Website Card Preview */}
        <div className="p-6 sm:p-10 bg-[#FAF9F5]/50">
          
          {/* Simulated Browser URL bar */}
          <div className="bg-white rounded-t-2xl border border-stone-200 px-4 py-2.5 flex items-center justify-between text-xs text-stone-500">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-stone-300"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-stone-300"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-stone-300"></span>
              <span className="ml-3 font-mono text-[11px] text-stone-600">
                https://store.{currentBusiness.id}.com/shop
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-800 font-bold">
              <span>OG Protocol Verified</span>
            </div>
          </div>

          {/* Product View */}
          <div className="bg-white border-x border-b border-stone-200 rounded-b-2xl p-6 sm:p-8">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
              
              {/* Product Photo */}
              <div className="md:col-span-5 relative">
                <div className="rounded-2xl overflow-hidden aspect-[4/3] bg-stone-100 border border-stone-200 relative shadow-sm group">
                  <img
                    src={currentBusiness.imageUrl}
                    alt={currentBusiness.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-stone-900 border border-stone-200 shadow-sm flex items-center gap-1.5">
                    <span>{currentBusiness.logoEmoji}</span>
                    <span>{currentBusiness.categoryLabel}</span>
                  </div>
                </div>
              </div>

              {/* Product Info & OG Snippet */}
              <div className="md:col-span-7 space-y-4">
                <div>
                  <span className="text-xs font-bold tracking-wider uppercase text-emerald-800">
                    {currentBusiness.categoryLabel}
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-stone-900 mt-1">
                    {currentBusiness.title}
                  </h3>
                  <div className="text-2xl font-black text-stone-900 mt-2 font-mono">
                    {currentBusiness.price}
                  </div>
                </div>

                {/* Rating Bar + The Minimal OG Snippet */}
                <div className="p-4 rounded-2xl bg-[#FAF9F5] border border-stone-200 space-y-3">
                  <div className="flex flex-wrap items-center gap-2.5 text-xs">
                    <div className="flex text-amber-500">
                      {'★'.repeat(5)}
                    </div>
                    <span className="font-bold text-stone-900">{currentBusiness.rating}</span>
                    <span className="text-stone-500">({currentBusiness.reviewCount.toLocaleString()} general stranger reviews)</span>
                  </div>

                  {/* >>> THE MINIMAL OG SNIPPET <<< */}
                  <div className="pt-2 border-t border-stone-200">
                    <motion.button
                      whileHover={{ scale: 1.018 }}
                      whileTap={{ scale: 0.985 }}
                      transition={{ type: 'spring', stiffness: 420, damping: 25 }}
                      onClick={() => setIsModalOpen(true)}
                      className="w-full group flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-4 py-3 rounded-xl bg-white hover:bg-emerald-50/50 border border-emerald-500/50 hover:border-emerald-600 text-left transition-colors shadow-sm hover:shadow-md cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        {/* Avatar stack */}
                        <div className="flex -space-x-1.5 shrink-0">
                          <img
                            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80"
                            alt="Contact"
                            className="w-6 h-6 rounded-full object-cover ring-2 ring-white"
                          />
                          <div className="w-6 h-6 rounded-full bg-stone-200 text-stone-600 flex items-center justify-center text-[10px] ring-2 ring-white font-bold">
                            ?
                          </div>
                        </div>

                        <div>
                          <div className="text-xs sm:text-sm font-bold text-stone-900 group-hover:text-emerald-900 leading-snug">
                            See who in your contacts uses this
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-1.5 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-stone-100">
                        <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200">
                          Check OG
                        </span>
                        <ChevronRight className="w-4 h-4 text-emerald-700 group-hover:translate-x-0.5 transition" />
                      </div>
                    </motion.button>
                  </div>
                </div>

                {/* Simulated Buy Action */}
                <div className="flex items-center gap-3 pt-1">
                  <button
                    onClick={() => setIsModalOpen(true)}
                    className="px-5 py-3 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold transition cursor-pointer"
                  >
                    Open Snippet Modal
                  </button>
                  <button className="px-6 py-3 rounded-xl bg-[#141413] hover:bg-stone-800 text-white font-bold text-xs sm:text-sm transition shadow-sm">
                    {currentBusiness.category === 'restaurant' ? 'Book Stay / Reserve' : 'Proceed to Checkout'}
                  </button>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* Snippet Code Bar */}
        <div className="p-4 sm:p-5 bg-[#141413] text-stone-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span className="font-semibold text-stone-200">
              Merchant 1-Line Embed Code:
            </span>
          </div>

          <div className="font-mono text-[11px] text-emerald-400 bg-black/60 px-3 py-1.5 rounded-lg border border-stone-800 overflow-x-auto">
            <code>&lt;script src="https://cdn.ognetwork.io/snippet.js" data-og-id="og_live_{currentBusiness.id}" async&gt;&lt;/script&gt;</code>
          </div>
        </div>

      </div>

      {/* Modal */}
      <OGTrustModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        business={currentBusiness}
      />
    </section>
  );
};
