import React, { useState } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';

interface NavbarProps {
  onOpenGetSnippet: () => void;
  onScrollToDemo: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenGetSnippet, onScrollToDemo }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-[#FAF9F5]/90 backdrop-blur-md border-b border-black/[0.06] transition-all">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand Name - Check OG words in sync, no logo */}
        <a href="#" className="flex items-baseline gap-1.5 group select-none py-1">
          <span className="text-xl font-bold tracking-tight text-[#141413] transition group-hover:text-black">
            Check
          </span>
          <span className="text-xl font-black tracking-tight text-[#141413] group-hover:text-emerald-700 transition">
            OG
          </span>
        </a>

        {/* Clean, un-cluttered Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-7 text-xs font-semibold tracking-wide uppercase text-stone-600">
          <a href="#problem" className="hover:text-black transition">
            Problem
          </a>
          <a
            href="#demo"
            onClick={(e) => { e.preventDefault(); onScrollToDemo(); }}
            className="hover:text-black transition"
          >
            Live Demo
          </a>
          <a href="#how-it-works" className="hover:text-black transition">
            How It Works
          </a>
          <a href="#roi" className="hover:text-black transition">
            ROI
          </a>
        </nav>

        {/* Single Crisp Action Button */}
        <div className="hidden sm:flex items-center gap-3">
          <button
            onClick={onOpenGetSnippet}
            className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#141413] hover:bg-stone-800 transition flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <span>Get Snippet</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Mobile menu toggle */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 rounded-lg text-stone-600 hover:text-black hover:bg-stone-200/50"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-black/[0.06] bg-[#FAF9F5] px-5 py-4 space-y-3">
          <a
            href="#problem"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-semibold text-stone-800 hover:text-black py-1"
          >
            Problem
          </a>
          <a
            href="#demo"
            onClick={() => { setMobileMenuOpen(false); onScrollToDemo(); }}
            className="block text-sm font-semibold text-stone-800 hover:text-black py-1"
          >
            Live Demo
          </a>
          <a
            href="#how-it-works"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-semibold text-stone-800 hover:text-black py-1"
          >
            How It Works
          </a>
          <a
            href="#roi"
            onClick={() => setMobileMenuOpen(false)}
            className="block text-sm font-semibold text-stone-800 hover:text-black py-1"
          >
            ROI
          </a>
          <div className="pt-2 border-t border-stone-200">
            <button
              onClick={() => { setMobileMenuOpen(false); onOpenGetSnippet(); }}
              className="w-full py-2.5 rounded-xl text-center text-xs font-bold text-white bg-[#141413]"
            >
              Get Free OG Snippet
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
