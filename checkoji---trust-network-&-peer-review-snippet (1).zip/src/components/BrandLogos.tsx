import React from 'react';

export const HimsAndHersLogo: React.FC<{ className?: string }> = ({ className = 'h-7' }) => (
  <div className={`inline-flex items-center ${className}`}>
    <span 
      className="text-stone-900 font-bold text-lg sm:text-xl tracking-tight select-none"
      style={{ fontFamily: "'Newsreader', Georgia, serif", letterSpacing: '-0.02em' }}
    >
      hims <span className="font-sans font-light text-stone-400">&amp;</span> hers
    </span>
  </div>
);

export const MastersUnionLogo: React.FC<{ className?: string }> = ({ className = 'h-7' }) => (
  <div className={`inline-flex items-center gap-2 ${className}`}>
    <div className="w-6 h-6 rounded bg-stone-900 text-white flex items-center justify-center font-bold text-xs tracking-tight">
      MU
    </div>
    <div className="flex flex-col leading-none text-left">
      <span className="font-bold text-stone-900 text-xs tracking-tight lowercase">masters'</span>
      <span className="font-bold text-stone-900 text-xs tracking-tight lowercase">union</span>
    </div>
  </div>
);

export const InsuranceDekhoLogo: React.FC<{ className?: string }> = ({ className = 'h-7' }) => (
  <div className={`inline-flex items-center gap-2 ${className}`}>
    <div className="w-7 h-7 rounded-lg bg-[#EE2C3C] flex items-center justify-center shrink-0 shadow-xs">
      <span className="text-white font-black text-xs tracking-tight">ID</span>
    </div>
    <div className="flex flex-col text-left leading-tight">
      <span className="font-bold text-stone-900 text-xs tracking-tight">InsuranceDekho</span>
      <span className="text-[9px] font-medium text-stone-500 tracking-tight">by CarDekho</span>
    </div>
  </div>
);

export const NoonLogo: React.FC<{ className?: string }> = ({ className = 'h-7' }) => (
  <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#FEE202] ${className}`}>
    <span className="font-black text-stone-900 text-xs tracking-tight lowercase">
      noon
    </span>
  </div>
);
