import React, { useState } from 'react';
import { ShieldCheck, MessageCircle, X, FileText, Lock, CheckCircle2, Building, Scale, ArrowUpRight } from 'lucide-react';

interface FooterProps {
  onOpenGetSnippet: () => void;
}

type LegalTab = 'terms' | 'privacy' | 'security';

export const Footer: React.FC<FooterProps> = ({ onOpenGetSnippet }) => {
  const [legalModalOpen, setLegalModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<LegalTab>('terms');

  return (
    <>
      <footer className="border-t border-stone-200 bg-[#FAF9F5] py-14 px-4 sm:px-6">
        <div className="max-w-5xl mx-auto space-y-10">
          
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            {/* Brand */}
            <div className="space-y-1.5 text-center md:text-left">
              <div className="flex items-baseline justify-center md:justify-start gap-1.5 select-none">
                <span className="text-xl font-bold tracking-tight text-[#141413]">
                  Check
                </span>
                <span className="text-xl font-black tracking-tight text-[#141413]">
                  OG
                </span>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-stone-200 text-stone-600 font-semibold ml-1">
                  Enterprise
                </span>
              </div>
              <p className="text-xs text-stone-500 max-w-sm leading-relaxed">
                Strangers rate products. Your circle tells the truth. The Trust Layer for Modern Commerce.
              </p>
            </div>

            {/* Founder Direct WhatsApp Contact Button (No visible phone number, wa.me link intact) */}
            <div className="flex flex-col sm:flex-row items-center gap-3">
              <a
                href="https://wa.me/919873027250?text=Hi%20Check%20OG%2C%20I%20would%20like%20to%20learn%20more%20about%20embedding%20the%20trust%20snippet"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm transition cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>Chat with Founder on WhatsApp</span>
              </a>

              <button
                onClick={onOpenGetSnippet}
                className="px-4 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs transition cursor-pointer shadow-sm"
              >
                Get Snippet Code
              </button>
            </div>
          </div>

          {/* Compliance & Trust Posture Badges - Super Subtle Design */}
          <div className="py-3 px-4 rounded-xl bg-stone-100/60 border border-stone-200/60 flex flex-wrap items-center justify-between gap-3 text-xs text-stone-500">
            <div className="flex items-center gap-1.5 font-medium text-stone-700">
              <ShieldCheck className="w-3.5 h-3.5 text-stone-400" />
              <span>Compliance & Security</span>
            </div>
            <div className="flex flex-wrap items-center gap-3 text-[11px] text-stone-500 font-mono">
              <span>SOC-2 Type II</span>
              <span>&bull;</span>
              <span>GDPR Ready</span>
              <span>&bull;</span>
              <span>Zero Persistence</span>
              <span>&bull;</span>
              <span>SHA-256 Hashing</span>
            </div>
          </div>

          {/* Nav links & Legal */}
          <div className="pt-6 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
            <div className="flex flex-wrap items-center justify-center gap-5 font-semibold text-stone-600">
              <a href="#story" className="hover:text-black transition">
                The Story
              </a>
              <a href="#demo" className="hover:text-black transition">
                Live Demo
              </a>
              <a href="#how-it-works" className="hover:text-black transition">
                How It Works
              </a>
              <a href="#roi-pricing" className="hover:text-black transition">
                ROI & Pricing
              </a>
              <a href="#snippet" className="hover:text-black transition">
                Embed
              </a>
              <button
                onClick={() => { setActiveTab('terms'); setLegalModalOpen(true); }}
                className="hover:text-black transition underline decoration-stone-300 font-semibold cursor-pointer"
              >
                Terms of Service
              </button>
              <button
                onClick={() => { setActiveTab('privacy'); setLegalModalOpen(true); }}
                className="hover:text-black transition underline decoration-stone-300 font-semibold cursor-pointer"
              >
                Privacy Policy
              </button>
              <button
                onClick={() => { setActiveTab('security'); setLegalModalOpen(true); }}
                className="hover:text-black transition underline decoration-stone-300 font-semibold cursor-pointer"
              >
                Security & SLA
              </button>
            </div>

            <div className="text-center sm:text-right text-[11px] text-stone-400 space-y-0.5">
              <div>© {new Date().getFullYear()} Check OG Technologies Inc. All rights reserved.</div>
              <div className="text-stone-400 font-medium">
                The Trust Layer for Modern Commerce
              </div>
            </div>
          </div>

        </div>
      </footer>

      {/* Comprehensive Enterprise Legal & Compliance Modal */}
      {legalModalOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
          onClick={() => setLegalModalOpen(false)}
        >
          <div 
            className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-stone-200 p-6 sm:p-8 overflow-hidden max-h-[88vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-stone-200 pb-4 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-stone-100 text-stone-900">
                  <Scale className="w-5 h-5 text-emerald-800" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-stone-900 leading-tight">
                    Check OG Enterprise Agreement & Governance
                  </h3>
                  <p className="text-xs text-stone-500">
                    Official Master Terms, Privacy Standard & Security Protocol
                  </p>
                </div>
              </div>
              <button
                onClick={() => setLegalModalOpen(false)}
                className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Tab Switcher */}
            <div className="flex items-center gap-2 border-b border-stone-200 pb-3 mb-4">
              <button
                onClick={() => setActiveTab('terms')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  activeTab === 'terms'
                    ? 'bg-[#141413] text-white shadow-xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                Terms of Service
              </button>
              <button
                onClick={() => setActiveTab('privacy')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  activeTab === 'privacy'
                    ? 'bg-[#141413] text-white shadow-xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                Privacy & Data Architecture
              </button>
              <button
                onClick={() => setActiveTab('security')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  activeTab === 'security'
                    ? 'bg-[#141413] text-white shadow-xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                Security & SLA
              </button>
            </div>

            {/* Content Area */}
            <div className="overflow-y-auto space-y-4 text-xs text-stone-600 leading-relaxed pr-2 font-normal">
              
              {activeTab === 'terms' && (
                <div className="space-y-4">
                  <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-stone-700">
                    <span className="font-bold block text-stone-900 mb-0.5">Effective Date: October 2026</span>
                    These Terms of Service ("Agreement") govern the integration and use of the Check OG snippet, API, and bilateral verification services provided by Check OG Technologies Inc.
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-sm mb-1">1. Bilateral Mutual Phone Book Principle</h4>
                    <p>
                      Check OG services are strictly predicated upon mutual contact verification. A connection between a shopper and a past verified reviewer is established only when both individuals hold each other's phone numbers in their respective phone books. Unilateral or cold contact directory harvesting is prohibited and mathematically prevented by our cryptographic graph.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-sm mb-1">2. Merchant Billing & Zero-Match Free Tier</h4>
                    <p>
                      Merchant accounts are billed on a utility basis of ₹2.00 INR per successful mutual check. A check is deemed billable solely when at least one verified mutual peer (named or anonymized) is discovered and rendered. If zero contacts match, no fee is incurred (₹0.00). No monthly platform seat fees or arbitrary tiers apply unless customized under enterprise master agreements.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-sm mb-1">3. Permitted Snippet Implementation</h4>
                    <p>
                      Merchants are granted a limited, revocable, non-exclusive license to embed the Check OG client script on verified domains. Merchants agree not to decompile, reverse-engineer, or attempt to intercept raw client-side cryptographic hashing routines.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-sm mb-1">4. Reviewer Anonymity & Unmasking Protocol</h4>
                    <p>
                      Every user on Check OG retains the inalienable right to remain anonymous to their contacts. In anonymized states, the shopper may submit an encrypted reveal request. Revealing identity is solely at the voluntary discretion of the reviewer.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-sm mb-1">5. Governing Law & Jurisdiction</h4>
                    <p>
                      This Agreement is governed by the laws applicable to commercial digital transactions, with dispute resolution conducted via binding arbitration in accordance with recognized international trade rules.
                    </p>
                  </div>
                </div>
              )}

              {activeTab === 'privacy' && (
                <div className="space-y-4">
                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-950 font-medium">
                    <div className="flex items-center gap-1.5 font-bold mb-0.5">
                      <Lock className="w-3.5 h-3.5 text-emerald-800" />
                      <span>Zero-Plaintext Privacy Commitment</span>
                    </div>
                    Plaintext phone books, address directories, and identity records are never received, stored, or indexed on Check OG servers.
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-sm mb-1">1. Cryptographic Salting & Hashing</h4>
                    <p>
                      When a shopper grants one-time contact permission via Web Contact Picker, Google People API, or OTP session, phone numbers are normalized (E.164 standard) and immediately hashed using SHA-256 with rotating cryptographic salts directly in the browser runtime. Only non-invertible hashes are queried.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-sm mb-1">2. GDPR & CCPA/CPRA Compliance</h4>
                    <p>
                      Check OG complies with Article 6(1)(a) (explicit affirmative consent) and Article 9 of the EU General Data Protection Regulation (GDPR), as well as the California Consumer Privacy Act (CCPA). Users have immediate access to revoke permissions, flush session tokens, or purge reviewer verification history at any time.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-sm mb-1">3. Merchant Data Isolation</h4>
                    <p>
                      Merchant storefronts never receive shopper contact lists or reviewer identities. All rendering occurs in isolated shadow-DOM containers protected by browser cross-origin policy.
                    </p>
                  </div>
                </div>
              )}

              {activeTab === 'security' && (
                <div className="space-y-4">
                  <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-stone-700">
                    <span className="font-bold block text-stone-900 mb-0.5">Service Level Agreement (SLA): 99.98%</span>
                    Check OG guarantees low-latency global CDN edge delivery with sub-35ms query resolution for merchant product snippet calls.
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-sm mb-1">1. SOC-2 Type II & ISO/IEC 27001 Alignment</h4>
                    <p>
                      Check OG maintains comprehensive organizational security controls, including automated vulnerability scanning, least-privilege IAM roles, continuous integrity checks, and third-party penetration testing.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-sm mb-1">2. Redundancy & DDoS Protection</h4>
                    <p>
                      All CDN edge nodes operate on enterprise Cloudflare and Google Cloud infrastructure with anycast routing, failover isolation, and rate-limiting to ensure merchant checkouts are never blocked or degraded.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-sm mb-1">3. Responsible Disclosure</h4>
                    <p>
                      Security researchers may report vulnerabilities directly to our engineering team at <span className="font-mono text-stone-800">security@ognetwork.io</span>. We operate a prompt 24-hour response triage SLA.
                    </p>
                  </div>
                </div>
              )}

            </div>

            {/* Footer */}
            <div className="pt-4 mt-4 border-t border-stone-200 flex items-center justify-between">
              <span className="text-[11px] text-stone-400 font-mono">
                Document Ref: COG-LEGAL-2026.V4
              </span>
              <button
                onClick={() => setLegalModalOpen(false)}
                className="px-5 py-2 rounded-xl bg-[#141413] text-white text-xs font-bold hover:bg-stone-800 cursor-pointer"
              >
                Acknowledge & Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
