import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Users, Smartphone, EyeOff, ShieldCheck, ArrowRight, 
  CheckCircle2, Lock, Unlock, Sparkles, Server, Store, Check, RefreshCw 
} from 'lucide-react';

export const VisualHowItWorks: React.FC = () => {
  const [activeStep, setActiveStep] = useState<number>(1);

  return (
    <section id="how-it-works" className="py-20 px-4 sm:px-6 max-w-5xl mx-auto border-t border-stone-200">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto mb-14">
        <span className="text-xs font-bold text-stone-500 uppercase tracking-widest block mb-2">
          The Mechanics & Data Flow
        </span>
        <h2 className="text-3xl sm:text-4xl font-black text-[#141413] tracking-tight">
          The Zero-Knowledge Handshake.{' '}
          <span className="font-editorial italic font-normal text-stone-600">
            Fluid & secure.
          </span>
        </h2>
        <p className="mt-3 text-stone-600 text-sm sm:text-base">
          How OG illustrates verified peer connections between the shopper's phone book, the merchant store, and the cryptographic verification engine.
        </p>
      </div>

      {/* MOTION ANIMATED HANDSHAKE ARCHITECTURE CARD */}
      <div className="bg-white rounded-3xl border border-stone-300/80 p-6 sm:p-10 shadow-xl mb-14 relative overflow-hidden">
        <div className="flex items-center justify-between pb-6 mb-8 border-b border-stone-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider">
                Live Data Handshake Architecture
              </h3>
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              Zero plaintext phone numbers ever cross into the merchant's servers.
            </p>
          </div>

          <span className="text-[11px] font-mono text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 font-bold">
            Protocol v1.4
          </span>
        </div>

        {/* The 3 Handshake Nodes with Motion Data Streams */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative items-center">
          
          {/* Node 1: User's Phone Book */}
          <motion.div 
            whileHover={{ y: -3 }}
            className="p-5 rounded-2xl bg-[#FAF9F5] border border-stone-200 relative text-center space-y-3"
          >
            <div className="w-12 h-12 rounded-2xl bg-white border border-stone-200 shadow-sm flex items-center justify-center mx-auto text-stone-900">
              <Smartphone className="w-6 h-6 text-stone-800" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">Origin Node</span>
              <h4 className="text-sm font-black text-stone-900">Shopper's Device</h4>
              <p className="text-[11px] text-stone-500 mt-1">
                Mutual contacts hashed locally into SHA-256 tokens.
              </p>
            </div>

            <div className="p-2 rounded-lg bg-stone-100 font-mono text-[10px] text-stone-600 truncate">
              hash: 8f4b...3a92
            </div>
          </motion.div>

          {/* Node 2: OG Network Backend (Cryptographic Verifier) */}
          <motion.div 
            whileHover={{ y: -3 }}
            className="p-5 rounded-2xl bg-[#141413] text-white relative text-center space-y-3 shadow-xl md:-my-3"
          >
            <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-stone-950 font-black flex items-center justify-center mx-auto text-sm shadow-md">
              OG
            </div>
            <div>
              <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase tracking-wider block">
                Verification Engine
              </span>
              <h4 className="text-sm font-black text-white">OG Network Backend</h4>
              <p className="text-[11px] text-stone-400 mt-1">
                Blind index match: Checks if hash exists in verified buyer ledger.
              </p>
            </div>

            {/* Glowing Handshake Pulse Indicator */}
            <div className="flex items-center justify-center gap-2 p-1.5 rounded-lg bg-stone-800/80 border border-stone-700 text-[10px] font-mono text-emerald-300">
              <motion.span 
                animate={{ scale: [1, 1.4, 1] }} 
                transition={{ repeat: Infinity, duration: 1.8 }}
                className="w-2 h-2 rounded-full bg-emerald-400"
              />
              <span>Mutual Match Validated</span>
            </div>
          </motion.div>

          {/* Node 3: Merchant Store Site */}
          <motion.div 
            whileHover={{ y: -3 }}
            className="p-5 rounded-2xl bg-[#FAF9F5] border border-stone-200 relative text-center space-y-3"
          >
            <div className="w-12 h-12 rounded-2xl bg-white border border-stone-200 shadow-sm flex items-center justify-center mx-auto text-emerald-700">
              <Store className="w-6 h-6 text-emerald-700" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">Destination</span>
              <h4 className="text-sm font-black text-stone-900">Merchant Store</h4>
              <p className="text-[11px] text-stone-500 mt-1">
                Snippet renders verified friend quote in-situ.
              </p>
            </div>

            <div className="p-2 rounded-lg bg-emerald-50 border border-emerald-200 text-[10px] font-bold text-emerald-800 truncate">
              ✓ "Rohan Mehta used this"
            </div>
          </motion.div>

        </div>

        {/* Animated Motion Particle Beam */}
        <div className="mt-8 pt-6 border-t border-stone-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2 text-stone-600">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
            <span className="text-[11px]">
              End-to-end cryptographic handshake. Contact lists are <strong>never stored in plaintext</strong>.
            </span>
          </div>

          <div className="flex items-center gap-2 font-mono text-[11px] text-stone-500">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
            <span>Handshake latency: &lt;48ms</span>
          </div>
        </div>
      </div>

      {/* 3 Core Editorial Principles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Principle 1 */}
        <motion.div 
          whileHover={{ y: -2 }}
          className="bg-white rounded-2xl border border-stone-300/80 p-6 shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="text-xs font-mono font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full inline-block mb-3 border border-emerald-200">
              01 &bull; TWO-WAY MATCH
            </div>

            <h3 className="text-base font-bold text-stone-900 mb-2">
              Mutual Phonebook Sync
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed font-normal">
              Contacts are matched <strong>only if saved in both phone books</strong>. If someone has your number but you haven’t saved them, they will never be matched.
            </p>

            <div className="mt-4 p-3 rounded-xl bg-[#FAF9F5] border border-stone-200 flex items-center justify-between text-xs">
              <span className="font-bold text-stone-800">Your Phone</span>
              <span className="text-emerald-700 font-bold">⇄ Mutual</span>
              <span className="font-bold text-stone-800">Friend's Phone</span>
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-stone-100 text-[11px] text-stone-500 flex items-center gap-1.5 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
            <span>Zero cold or one-sided exposure</span>
          </div>
        </motion.div>

        {/* Principle 2 */}
        <motion.div 
          whileHover={{ y: -2 }}
          className="bg-white rounded-2xl border border-stone-300/80 p-6 shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="text-xs font-mono font-bold text-stone-700 bg-stone-100 px-2.5 py-0.5 rounded-full inline-block mb-3 border border-stone-200">
              02 &bull; 1-TIME PERMISSION
            </div>

            <h3 className="text-base font-bold text-stone-900 mb-2">
              Consent via Cookie or OTP
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed font-normal">
              Just like <strong>Truecaller</strong> or <strong>WhatsApp</strong>, users grant a 1-time mutual contact sync via mobile OTP or 1-click cookie consent upon first check.
            </p>

            <div className="mt-4 p-3 rounded-xl bg-[#FAF9F5] border border-stone-200 space-y-1 text-xs">
              <div className="font-bold text-stone-800">1-Click Consent / SMS OTP</div>
              <p className="text-[10px] text-stone-500">
                Salted hashes generated on client side. No contact scraping.
              </p>
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-stone-100 text-[11px] text-stone-500 flex items-center gap-1.5 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5 text-stone-700 shrink-0" />
            <span>Shoppers stay in 100% control</span>
          </div>
        </motion.div>

        {/* Principle 3 */}
        <motion.div 
          whileHover={{ y: -2 }}
          className="bg-white rounded-2xl border border-stone-300/80 p-6 shadow-sm flex flex-col justify-between"
        >
          <div>
            <div className="text-xs font-mono font-bold text-amber-900 bg-amber-50 px-2.5 py-0.5 rounded-full inline-block mb-3 border border-amber-200">
              03 &bull; ANONYMITY & UNMASK
            </div>

            <h3 className="text-base font-bold text-stone-900 mb-2">
              Reviewer Control & Unmasking
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed font-normal">
              Reviewers can choose to stay anonymous. When shoppers see an anonymous mutual contact, they can tap <strong>"Ask to unmask"</strong> to request a private reveal.
            </p>

            <div className="mt-4 p-3 rounded-xl bg-amber-50/60 border border-amber-200 flex items-center justify-between text-xs">
              <span className="text-[11px] font-bold text-stone-800">Anonymous Contact</span>
              <span className="text-[10px] font-bold bg-[#141413] text-white px-2 py-0.5 rounded">
                Ask to unmask
              </span>
            </div>
          </div>

          <div className="pt-4 mt-4 border-t border-stone-100 text-[11px] text-stone-500 flex items-center gap-1.5 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5 text-amber-700 shrink-0" />
            <span>Reviewers decide who sees their name</span>
          </div>
        </motion.div>

      </div>
    </section>
  );
};
