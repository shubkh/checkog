import React from 'react';
import { ArrowRight, Sparkles, MessageCircle, AlertCircle, CheckCircle2, Star } from 'lucide-react';

interface StoryHeroProps {
  onScrollToDemo: () => void;
  onOpenGetSnippet: () => void;
}

export const StoryHero: React.FC<StoryHeroProps> = ({ onScrollToDemo, onOpenGetSnippet }) => {
  return (
    <section className="relative pt-12 pb-20 sm:pt-20 sm:pb-28 px-4 sm:px-6 max-w-5xl mx-auto">
      {/* Background soft subtle grain and warmth */}
      <div className="text-center space-y-6 max-w-3xl mx-auto">
        {/* Subtle thesis pill */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-stone-200/60 border border-stone-300/80 text-stone-700 text-xs font-semibold tracking-wide">
          <span>The Trust Layer for Modern Commerce</span>
        </div>

        {/* Core Headline */}
        <h1 className="text-4xl sm:text-6xl font-black tracking-tight text-[#141413] leading-[1.12]">
          Strangers rate products.{' '}
          <span className="font-editorial italic font-normal text-stone-600 block sm:inline">
            Your circle tells the truth.
          </span>
        </h1>

        {/* Brief Narrative */}
        <p className="text-base sm:text-xl text-stone-600 max-w-2xl mx-auto leading-relaxed font-normal">
          Every website has 4.8 stars from 10,000 strangers. Nobody believes them. When buyers make real decisions, they ask people they know.
        </p>

        {/* Value Premise */}
        <p className="text-sm sm:text-base text-stone-800 font-medium max-w-xl mx-auto">
          <strong>Check OG</strong> embeds a 1-click snippet next to ratings. Shoppers instantly see who in their mutual phone book has verified the product.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-3">
          <button
            onClick={onScrollToDemo}
            className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-[#141413] hover:bg-stone-800 text-white font-bold text-sm sm:text-base transition shadow-md shadow-black/10 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>Try Live Snippet</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenGetSnippet}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-white hover:bg-stone-50 text-stone-900 font-bold text-sm sm:text-base border border-stone-300 transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
          >
            <span>Embed Snippet</span>
            <span className="text-xs px-2 py-0.5 rounded bg-stone-100 text-stone-600 font-semibold font-mono">₹2 / check</span>
          </button>
        </div>
      </div>

      {/* Visual Contrast: Anonymous Internet vs. OG Mutual Network */}
      <div className="mt-14 sm:mt-16 max-w-4xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
          
          {/* Left: The Broken Stranger Review Problem */}
          <div className="bg-[#F2EFE8] rounded-2xl border border-stone-300/80 p-5 sm:p-6 space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between text-xs font-semibold text-stone-500 uppercase tracking-wider">
              <span>The Stranger Review Problem</span>
              <span className="text-rose-600 font-bold flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                Zero Trust
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-white/70 border border-stone-200 space-y-2">
              <div className="flex items-center gap-1.5 text-xs">
                <div className="flex text-amber-500">★★★★★</div>
                <span className="font-bold text-stone-900">4.9 / 5.0</span>
                <span className="text-stone-500">(14,200 stranger reviews)</span>
              </div>
              <p className="text-xs text-stone-500 italic">
                "Best product ever! Life changing quality!" — <span className="font-semibold text-stone-700">user_89142</span>
              </p>
            </div>

            <div className="text-xs text-stone-600 space-y-1.5 pt-1">
              <div className="flex items-start gap-2">
                <span className="text-rose-500 font-bold">&times;</span>
                <span>Shopper suspects bot-generated text or paid marketing.</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-rose-500 font-bold">&times;</span>
                <span>Hesitation kicks in. Cart is abandoned.</span>
              </div>
            </div>
          </div>

          {/* Right: The OG Mutual Network Reality */}
          <div className="bg-white rounded-2xl border-2 border-emerald-600/30 p-5 sm:p-6 space-y-3 shadow-lg shadow-emerald-950/5 relative">
            <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider">
              <span className="text-emerald-800 font-bold">The OG Network Trust</span>
              <span className="text-emerald-700 font-bold flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Mutual Contacts
              </span>
            </div>

            {/* Snippet Pill */}
            <div 
              onClick={onScrollToDemo}
              className="p-3.5 rounded-xl bg-[#FAF9F5] border border-emerald-400 hover:border-emerald-600 cursor-pointer transition shadow-sm space-y-2 group"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-[#141413] text-white flex items-center justify-center text-[10px] font-black">
                    OG
                  </div>
                  <span className="text-xs font-bold text-stone-900 group-hover:text-emerald-800">
                    Rohan & Sneha in your contacts use this
                  </span>
                </div>
                <span className="text-xs font-bold text-emerald-700 group-hover:translate-x-0.5 transition">&rarr;</span>
              </div>

              <div className="flex items-center gap-2 pt-1 border-t border-stone-200/60 text-[11px] text-stone-600">
                <span className="text-emerald-700 font-bold">✓</span>
                <span>Mutual phone book match: Verified buyers you personally know.</span>
              </div>
            </div>

            <div className="text-xs text-stone-700 space-y-1.5 pt-1 font-medium">
              <div className="flex items-start gap-2">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>70%+ of shoppers convert when a mutual contact vouches.</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-emerald-600 font-bold">✓</span>
                <span>Full privacy: Reviewers can stay anonymous or unmask on request.</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
