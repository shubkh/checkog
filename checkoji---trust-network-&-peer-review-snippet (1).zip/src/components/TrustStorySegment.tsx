import React from 'react';
import { ShieldCheck, MessageSquare, HeartHandshake, EyeOff, Lock, UserCheck } from 'lucide-react';

export const TrustStorySegment: React.FC = () => {
  return (
    <section id="problem" className="py-20 px-4 sm:px-6 max-w-5xl mx-auto border-t border-stone-200">
      {/* Editorial Header */}
      <div className="max-w-2xl mb-14">
        <span className="text-xs font-bold text-stone-500 uppercase tracking-widest block mb-2">
          The Manifesto
        </span>
        <h2 className="text-3xl sm:text-4xl font-black text-[#141413] tracking-tight leading-tight">
          Commerce used to run on reputation.{' '}
          <span className="font-editorial italic font-normal text-stone-600">
            We let algorithms replace our friends.
          </span>
        </h2>
      </div>

      {/* 3 Story Chapters Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* Chapter 1 */}
        <div className="space-y-3">
          <div className="text-xs font-mono font-bold text-stone-400">
            ACT I &bull; THE PARADOX
          </div>
          <h3 className="text-lg font-bold text-stone-900">
            The Stranger Economy
          </h3>
          <p className="text-sm text-stone-600 leading-relaxed font-normal">
            For twenty years, the web taught us to trust nameless usernames. Today, that system is collapsing under the weight of AI-generated prose, paid influencer seeding, and incentivized five-star unboxings.
          </p>
          <div className="p-3 rounded-xl bg-stone-100/70 border border-stone-200 text-xs text-stone-700 italic">
            "When every product has 4.8 stars, no product has any trust."
          </div>
        </div>

        {/* Chapter 2 */}
        <div className="space-y-3">
          <div className="text-xs font-mono font-bold text-stone-400">
            ACT II &bull; SKIN IN THE GAME
          </div>
          <h3 className="text-lg font-bold text-stone-900">
            Social Accountability
          </h3>
          <p className="text-sm text-stone-600 leading-relaxed font-normal">
            A stranger online loses nothing by leaving a fraudulent review. But when your college friend, gym partner, or colleague recommends a brand, their personal reputation is attached to that advice.
          </p>
          <div className="p-3 rounded-xl bg-stone-100/70 border border-stone-200 text-xs text-stone-700 italic">
            "A one-line endorsement from someone in your phonebook is worth a thousand five-star strangers."
          </div>
        </div>

        {/* Chapter 3 */}
        <div className="space-y-3">
          <div className="text-xs font-mono font-bold text-stone-400">
            ACT III &bull; THE OG THESIS
          </div>
          <h3 className="text-lg font-bold text-stone-900">
            The Mutual Trust Protocol
          </h3>
          <p className="text-sm text-stone-600 leading-relaxed font-normal">
            OG brings real-world word-of-mouth directly into the digital checkout flow. <strong>No public social feed. No spamming contacts.</strong> Just a simple, cryptographic mutual check that answers the only question that matters: <em>Did someone I actually trust use this?</em>
          </p>
          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 font-medium">
            Mutual phone book matches only. Privacy guaranteed.
          </div>
        </div>

      </div>
    </section>
  );
};
