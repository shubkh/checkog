export interface ContactPeer {
  id: string;
  name: string;
  avatarUrl?: string;
  isAnonymous: boolean;
  anonymousLabel?: string;
  contactSource: 'phonebook' | 'google' | 'whatsapp';
  relationship: string;
  rating: number;
  hasWrittenReview: boolean;
  reviewText?: string;
  isMutualContact: boolean;
}

export interface BusinessItem {
  id: string;
  category: 'd2c' | 'restaurant' | 'fintech' | 'retail';
  categoryLabel: string;
  brandName: string;
  logoEmoji: string;
  title: string;
  price: string;
  rating: number;
  reviewCount: number;
  imageUrl: string;
  accentColor: string;
  contacts: ContactPeer[];
}

export type SnippetVariant = 'pill' | 'minimal' | 'badge';
