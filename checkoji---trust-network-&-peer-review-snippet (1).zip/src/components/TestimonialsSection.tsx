import React from 'react';
import { HimsAndHersLogo, MastersUnionLogo, InsuranceDekhoLogo, NoonLogo } from './BrandLogos';

interface TestimonialItem {
  logoComponent: React.ReactNode;
  quote: string;
  role: string;
}

const testimonials: TestimonialItem[] = [
  {
    logoComponent: <MastersUnionLogo />,
    quote:
      'This has been a complete game-changer for us. When prospective candidates see which alumni or coworkers in their mutual phone book graduated from Masters’ Union, consultation conversions surged overnight.',
    role: "Masters' Union",
  },
  {
    logoComponent: <InsuranceDekhoLogo />,
    quote:
      'Insurance is a pure trust category. Knowing that a mutual friend actively holds an approved health policy via InsuranceDekho eliminated skepticism far better than thousands of anonymous stranger reviews.',
    role: 'InsuranceDekho by CarDekho',
  },
  {
    logoComponent: <NoonLogo />,
    quote:
      'A complete game-changer for regional e-commerce. When cross-border shoppers see that someone in their mutual phone book bought from this seller, high-value cart abandonment dropped instantly.',
    role: 'noon',
  },
  {
    logoComponent: <HimsAndHersLogo />,
    quote:
      'In personal wellness and healthcare, stranger testimonials feel synthetic. Discovering that a mutual contact trusts hims & hers gave subscribers the unvarnished confidence to complete their consult.',
    role: 'hims & hers (NYSE: HIMS)',
  },
];

export const TestimonialsSection: React.FC = () => {
  return (
    <section id="testimonials" className="py-20 px-4 sm:px-6 max-w-5xl mx-auto border-t border-stone-200">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-14">
        <span className="text-xs font-bold text-stone-500 uppercase tracking-widest block mb-2">
          Enterprise Proof
        </span>
        <h2 className="text-3xl sm:text-5xl font-black text-[#141413] tracking-tight">
          "A complete game-changer for us."
        </h2>
        <p className="mt-3 text-stone-600 text-sm sm:text-base max-w-xl mx-auto">
          How leading international enterprises turn cold skepticism into verified peer conversion.
        </p>
      </div>

      {/* Testimonials 2x2 Grid - Cleaned as requested: Logo, name, and quote only */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {testimonials.map((t, idx) => (
          <div
            key={idx}
            className="bg-white rounded-2xl border border-stone-200/90 p-6 sm:p-7 shadow-xs flex flex-col justify-between hover:shadow-sm transition space-y-4"
          >
            <div>
              {/* Brand Logo Header */}
              <div className="border-b border-stone-100 pb-4 mb-4 flex items-center h-8">
                {t.logoComponent}
              </div>

              {/* Quote */}
              <p className="text-xs sm:text-sm text-stone-700 leading-relaxed font-normal">
                "{t.quote}"
              </p>
            </div>

            {/* Brand Name Footer */}
            <div className="pt-3 border-t border-stone-100">
              <span className="font-bold text-stone-900 text-xs">{t.role}</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
