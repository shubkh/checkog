import React, { useState } from 'react';
import { Lock, Smartphone, Sliders, ShieldCheck, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const PrivacyAssurance: React.FC = () => {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const assurances = [
    {
      id: 0,
      icon: <Lock className="w-3.5 h-3.5 text-stone-700 shrink-0" />,
      title: 'End-to-End Encryption',
      detail: 'Client-side SHA-256 salted tokens. Raw phone numbers are never transmitted over the network.',
    },
    {
      id: 1,
      icon: <Smartphone className="w-3.5 h-3.5 text-stone-700 shrink-0" />,
      title: 'Zero Phone Book Storage',
      detail: 'Contacts are never stored in plaintext, logged to disk, or made accessible to merchant storefronts.',
    },
    {
      id: 2,
      icon: <Sliders className="w-3.5 h-3.5 text-stone-700 shrink-0" />,
      title: 'Granular Consent Control',
      detail: 'Bilateral mutual consent only. Reviewers can stay anonymous or unmask identity upon direct request.',
    },
  ];

  const toggleExpand = (idx: number) => {
    setExpandedIndex((prev) => (prev === idx ? null : idx));
  };

  return (
    <div className="pt-3 border-t border-stone-200/80">
      <div className="flex items-center justify-between text-[10px] font-bold text-stone-400 uppercase tracking-wider mb-2">
        <div className="flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
          <span>Privacy & Protocol Guarantees</span>
        </div>
        <span className="text-[10px] text-stone-400 font-normal lowercase italic">
          (click badge to expand)
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        {assurances.map((item) => {
          const isExpanded = expandedIndex === item.id;
          return (
            <div
              key={item.id}
              onClick={() => toggleExpand(item.id)}
              className={`p-2.5 rounded-xl border text-[11px] cursor-pointer transition-all ${
                isExpanded
                  ? 'bg-emerald-50/60 border-emerald-400 shadow-sm'
                  : 'bg-stone-50 hover:bg-stone-100/80 border-stone-200/80'
              }`}
            >
              <div className="flex items-center justify-between gap-1.5">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="p-1 rounded-md bg-white border border-stone-200 shrink-0 shadow-2xs">
                    {item.icon}
                  </div>
                  <span className="font-bold text-stone-800 text-xs truncate">
                    {item.title}
                  </span>
                </div>
                <ChevronDown
                  className={`w-3.5 h-3.5 text-stone-400 shrink-0 transition-transform duration-200 ${
                    isExpanded ? 'rotate-180 text-emerald-700' : ''
                  }`}
                />
              </div>

              {/* Description revealed on expansion */}
              <AnimatePresence initial={false}>
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <p className="pt-2 text-[11px] text-stone-600 leading-snug border-t border-emerald-200/60 mt-2 font-normal">
                      {item.detail}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </div>
  );
};
