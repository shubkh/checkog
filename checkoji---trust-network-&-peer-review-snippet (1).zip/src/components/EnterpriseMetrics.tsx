import React from 'react';

export const EnterpriseMetrics: React.FC = () => {
  const stats = [
    {
      value: '45M+',
      label: 'Connections Verified',
    },
    {
      value: '$5B+',
      label: 'Commerce Enabled',
    },
    {
      value: '350+',
      label: 'Brands Served',
    },
  ];

  return (
    <section className="py-10 px-4 sm:px-6 max-w-4xl mx-auto">
      <div className="bg-[#FAF9F5] rounded-2xl border border-stone-200/60 p-6 sm:p-8">
        
        {/* Header */}
        <div className="text-center mb-8">
          <span className="text-[11px] font-mono font-semibold tracking-widest uppercase text-stone-400 block mb-1">
            Metrics
          </span>
          <h3 className="text-xl sm:text-2xl font-bold text-stone-900 tracking-tight">
            Making trust measurable.
          </h3>
        </div>

        {/* Counter Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 divide-y md:divide-y-0 md:divide-x divide-stone-200/80">
          {stats.map((stat, idx) => (
            <div 
              key={idx} 
              className={`text-center space-y-1 ${idx > 0 ? 'pt-5 md:pt-0 md:pl-6' : ''}`}
            >
              <div className="text-3xl sm:text-4xl font-black text-stone-900 tracking-tight font-mono">
                {stat.value}
              </div>
              <div className="text-xs sm:text-sm font-medium text-stone-600">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
