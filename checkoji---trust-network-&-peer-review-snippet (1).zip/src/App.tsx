import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { StoryHero } from './components/StoryHero';
import { EnterpriseMetrics } from './components/EnterpriseMetrics';
import { TrustStorySegment } from './components/TrustStorySegment';
import { InteractiveShowcase } from './components/InteractiveShowcase';
import { TestimonialsSection } from './components/TestimonialsSection';
import { VisualHowItWorks } from './components/VisualHowItWorks';
import { PricingAndRoiCalculator } from './components/PricingAndRoiCalculator';
import { WidgetCustomizer } from './components/WidgetCustomizer';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { GetSnippetModal } from './components/GetSnippetModal';

export default function App() {
  const [isGetSnippetModalOpen, setIsGetSnippetModalOpen] = useState(false);

  const handleScrollToDemo = () => {
    const demoEl = document.getElementById('demo');
    if (demoEl) {
      demoEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF9F5] text-[#141413] selection:bg-[#E2DDD2] selection:text-[#141413]">
      {/* Sleek, un-cluttered Navbar */}
      <Navbar
        onOpenGetSnippet={() => setIsGetSnippetModalOpen(true)}
        onScrollToDemo={handleScrollToDemo}
      />

      <main>
        {/* Story-First Hero: Strangers write reviews. Friends tell the truth. */}
        <StoryHero
          onScrollToDemo={handleScrollToDemo}
          onOpenGetSnippet={() => setIsGetSnippetModalOpen(true)}
        />

        {/* Live Global Counters & Enterprise Scale Proof */}
        <EnterpriseMetrics />

        {/* The Editorial Manifesto & Narrative Deep-Dive */}
        <TrustStorySegment />

        {/* The Live Interactive Showcase & Testbed */}
        <InteractiveShowcase />

        {/* Brand Testimonials: Masters' Union, InsuranceDekho, Spinny, Mokobara */}
        <TestimonialsSection />

        {/* Visual Diagrams: Data Handshake with Motion Animations */}
        <VisualHowItWorks />

        {/* Combined ₹2 Pricing & High-Scale ROI Engine */}
        <PricingAndRoiCalculator
          onOpenGetSnippet={() => setIsGetSnippetModalOpen(true)}
        />

        {/* Integration Code & Standalone og-snippet.js Download */}
        <WidgetCustomizer />

        {/* Frequently Asked Questions */}
        <FaqSection />
      </main>

      {/* Editorial Footer */}
      <Footer onOpenGetSnippet={() => setIsGetSnippetModalOpen(true)} />

      {/* Merchant Setup Modal */}
      <GetSnippetModal
        isOpen={isGetSnippetModalOpen}
        onClose={() => setIsGetSnippetModalOpen(false)}
      />
    </div>
  );
}
