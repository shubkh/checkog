import React, { useState } from 'react';
import { Copy, Check, Download, Sliders, FileCode, CheckCircle2 } from 'lucide-react';
import { SnippetVariant } from '../types';

export const WidgetCustomizer: React.FC = () => {
  const [variant, setVariant] = useState<SnippetVariant>('pill');
  const [accent, setAccent] = useState<string>('#059669');
  const [platform, setPlatform] = useState<'html' | 'shopify' | 'react' | 'webflow'>('html');
  const [copied, setCopied] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  const getCodeSnippet = () => {
    switch (platform) {
      case 'shopify':
        return `<!-- 1. Add to sections/main-product.liquid -->
<script src="https://cdn.ognetwork.io/snippet.js" data-og-id="og_live_{{ shop.permanent_domain | md5 }}" async></script>

<!-- 2. Place this container below your star ratings -->
<div id="og-trust-snippet"
     data-item-id="{{ product.id }}"
     data-variant="${variant}">
</div>`;

      case 'react':
        return `// Next.js / React Component
import Script from 'next/script';

export function OGSnippet({ productId }: { productId: string }) {
  return (
    <>
      <Script 
        src="https://cdn.ognetwork.io/snippet.js" 
        data-og-id="og_live_YOUR_STORE_ID" 
        strategy="lazyOnload" 
      />
      <div 
        id="og-trust-snippet"
        data-item-id={productId}
        data-variant="${variant}"
      />
    </>
  );
}`;

      case 'webflow':
        return `<!-- Webflow Embed Component -->
<script src="https://cdn.ognetwork.io/snippet.js" data-og-id="og_live_webflow_store" async></script>
<div id="og-trust-snippet" 
     data-item-id="wflow_{{wf_current_id}}" 
     data-variant="${variant}">
</div>`;

      case 'html':
      default:
        return `<!-- 1. Include the OG asynchronous script before </body> -->
<script src="https://cdn.ognetwork.io/snippet.js" data-og-id="og_live_merchant_id" async></script>

<!-- 2. Place the OG snippet container next to your star reviews -->
<div id="og-trust-snippet" 
     data-item-id="product_101" 
     data-variant="${variant}">
</div>`;
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getCodeSnippet());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const fileContent = `/**
 * OG Peer Trust Snippet v1.0
 * Official embed script for OG (Mutual Contacts Trust Network)
 * (c) 2026 OG Inc.
 */
(function() {
  function initOG() {
    var containers = document.querySelectorAll('#og-trust-snippet, [data-og-container]');
    containers.forEach(function(el) {
      if (el.getAttribute('data-og-ready')) return;
      el.setAttribute('data-og-ready', 'true');

      var btn = document.createElement('button');
      btn.type = 'button';
      btn.style.cssText = 'display:inline-flex;align-items:center;gap:8px;padding:7px 14px;border-radius:9999px;background:#FFFFFF;color:#0F172A;border:1px solid #10B981;font-size:12px;font-weight:700;font-family:system-ui,sans-serif;cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,0.06);';
      btn.innerHTML = '<span style="color:#059669;font-weight:900;">OG</span> <span>See who in your contacts uses this &rarr;</span>';

      btn.onclick = function() {
        console.log("Check OG Trust Network: Mutual contacts found in your phone book.");
      };

      el.appendChild(btn);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initOG);
  } else {
    initOG();
  }
})();
`;

    const blob = new Blob([fileContent], { type: 'application/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'og-snippet.js';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  return (
    <section id="snippet" className="py-20 px-4 sm:px-6 max-w-5xl mx-auto border-t border-stone-200">
      <div className="text-center max-w-2xl mx-auto mb-14">
        <span className="text-xs font-bold text-stone-500 uppercase tracking-widest block mb-2">
          Embed & Integration
        </span>
        <h2 className="text-3xl sm:text-4xl font-black text-[#141413] tracking-tight">
          Drop it in with 1 line.{' '}
          <span className="font-editorial italic font-normal text-stone-600">
            Or self-host.
          </span>
        </h2>
        <p className="mt-3 text-stone-600 text-sm sm:text-base">
          Copy the async script for Shopify, React, or Webflow, or download the lightweight <code className="text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded font-mono text-xs">og-snippet.js</code> file to host on your own server.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Controls */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-5">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Sliders className="w-4 h-4 text-emerald-600" />
            <h3 className="font-bold text-slate-900 text-sm">Snippet Style</h3>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-2">
              Variant Layout
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'pill', label: 'Pill Badge' },
                { id: 'minimal', label: 'Minimal Text' },
                { id: 'badge', label: 'Compact Tag' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setVariant(item.id as SnippetVariant)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold border text-center transition ${
                    variant === item.id
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-800'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Live Mini Preview */}
          <div className="pt-3 border-t border-slate-100">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
              Live Snippet Preview
            </span>
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-md bg-emerald-600 text-white font-extrabold flex items-center justify-center text-[10px]">
                  OG
                </span>
                <span className="text-xs font-bold text-slate-900">
                  Rohan & 2 others in your contacts use this
                </span>
              </div>
              <span className="text-xs text-emerald-700 font-bold">&rarr;</span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-emerald-50/60 border border-emerald-100 text-xs text-emerald-900 space-y-1">
            <div className="flex items-center gap-1.5 font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>₹2 per successful check</span>
            </div>
            <p className="text-[11px] text-emerald-800">
              Only charged when 1+ mutual contacts (named or anonymous) are discovered. ₹0 if no contacts found.
            </p>
          </div>
        </div>

        {/* Code View */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3 mb-4">
              {/* Platform buttons */}
              <div className="flex items-center gap-1.5">
                {[
                  { id: 'html', label: 'HTML / JS' },
                  { id: 'shopify', label: 'Shopify' },
                  { id: 'react', label: 'React / Next' },
                  { id: 'webflow', label: 'Webflow' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setPlatform(item.id as any)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                      platform === item.id
                        ? 'bg-slate-900 text-white'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              {/* Copy button */}
              <button
                onClick={handleCopy}
                className="flex items-center gap-1 text-xs font-bold px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 transition cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            {/* Code */}
            <div className="rounded-xl bg-slate-900 text-emerald-300 p-4 font-mono text-xs overflow-x-auto min-h-[180px]">
              <pre>{getCodeSnippet()}</pre>
            </div>
          </div>

          {/* Download button */}
          <div className="mt-6 pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <FileCode className="w-4 h-4 text-emerald-600" />
                <span>Upload to your website / server</span>
              </h4>
              <p className="text-[11px] text-slate-500">
                Self-host the script directly on your own hosting or CDN.
              </p>
            </div>

            <button
              onClick={handleDownloadFile}
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-sm shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>{downloadSuccess ? 'Downloaded!' : 'Download og-snippet.js'}</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
