import React, { useState } from 'react';
import { X, Check, Copy, ArrowRight, CheckCircle2 } from 'lucide-react';

interface GetSnippetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GetSnippetModal: React.FC<GetSnippetModalProps> = ({ isOpen, onClose }) => {
  const [step, setStep] = useState<'form' | 'generated'>('form');
  const [brandName, setBrandName] = useState('');
  const [websiteDomain, setWebsiteDomain] = useState('');
  const [platform, setPlatform] = useState('shopify');
  const [generatedKey, setGeneratedKey] = useState('');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanDomain = (websiteDomain || 'brand.com').replace(/https?:\/\//, '').replace(/\/.*$/, '');
    const randomSlug = Math.random().toString(36).substring(2, 7);
    const key = `og_live_${cleanDomain.replace(/[^a-zA-Z0-9]/g, '_')}_${randomSlug}`;
    setGeneratedKey(key);
    setStep('generated');
  };

  const snippetTag = `<!-- Place before </body> -->
<script src="https://cdn.ognetwork.io/snippet.js" data-og-id="${generatedKey}" async></script>

<!-- Place where reviews appear -->
<div id="og-trust-snippet" data-item-id="product_id"></div>`;

  const handleCopy = () => {
    navigator.clipboard.writeText(snippetTag);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div 
        className="relative w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-2xl p-6 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
          <div className="flex items-center gap-2">
            <span className="w-7 h-7 rounded-lg bg-emerald-600 text-white font-extrabold flex items-center justify-center text-xs">
              OG
            </span>
            <h3 className="font-bold text-slate-900 text-base">
              {step === 'form' ? 'Get OG Snippet' : 'Your Live Embed Code is Ready!'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {step === 'form' ? (
          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Brand / Store Name
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Mokobara or Subko Coffee"
                value={brandName}
                onChange={(e) => setBrandName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Store Website URL
              </label>
              <input
                type="text"
                required
                placeholder="e.g. mokobara.com"
                value={websiteDomain}
                onChange={(e) => setWebsiteDomain(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Website Platform
              </label>
              <select
                value={platform}
                onChange={(e) => setPlatform(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
              >
                <option value="shopify">Shopify</option>
                <option value="woocommerce">WooCommerce (WordPress)</option>
                <option value="webflow">Webflow</option>
                <option value="react">React / Next.js</option>
                <option value="custom">Custom HTML / PHP</option>
              </select>
            </div>

            <div className="p-3 rounded-xl bg-emerald-50 text-xs text-emerald-900 space-y-0.5">
              <span className="font-bold">Simple Pricing:</span>
              <p className="text-[11px] text-emerald-800">
                ₹2 per successful check (₹0 if no contacts found). First 100 checks are completely free!
              </p>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm transition shadow-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Generate Snippet Key</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <div className="space-y-4">
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <span className="font-bold">Your Store Token:</span>
                <p className="font-mono text-[11px] text-emerald-800 break-all">{generatedKey}</p>
              </div>
            </div>

            <div>
              <span className="block text-xs font-semibold text-slate-700 mb-1.5">
                Embed Snippet:
              </span>
              <div className="p-3 rounded-xl bg-slate-900 font-mono text-xs text-emerald-300 overflow-x-auto">
                <pre>{snippetTag}</pre>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={handleCopy}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-emerald-700 transition cursor-pointer"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'Copied to Clipboard!' : 'Copy Code'}</span>
              </button>

              <button
                onClick={() => setStep('form')}
                className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition"
              >
                Back
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
