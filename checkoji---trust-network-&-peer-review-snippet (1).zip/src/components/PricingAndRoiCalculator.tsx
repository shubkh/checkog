import React, { useState } from 'react';
import { Check, Sparkles, TrendingUp, DollarSign, ArrowRight, ShieldCheck, Zap } from 'lucide-react';

interface PricingAndRoiCalculatorProps {
  onOpenGetSnippet: () => void;
}

export const PricingAndRoiCalculator: React.FC<PricingAndRoiCalculatorProps> = ({ onOpenGetSnippet }) => {
  // Sliders
  const [monthlyChecks, setMonthlyChecks] = useState<number>(4500);
  const [ticketSize, setTicketSize] = useState<number>(3200); // Average Order Value in INR
  const [conversionLiftPct, setConversionLiftPct] = useState<number>(45); // 45% conversion probability for peer-checkers

  // Calculations
  const ogCost = monthlyChecks * 2; // ₹2 per check
  // Typical incremental orders from peer validation
  const convertedBuyers = Math.round(monthlyChecks * (conversionLiftPct / 100));
  const incrementalRevenue = convertedBuyers * ticketSize;
  const annualIncrementalRevenue = incrementalRevenue * 12;
  const roiMultiple = ogCost > 0 ? Math.round(incrementalRevenue / ogCost) : 0;

  // Format in INR Lakhs / Crores
  const formatINR = (val: number) => {
    if (val >= 10000000) {
      return `₹${(val / 10000000).toFixed(2)} Cr`;
    }
    if (val >= 100000) {
      return `₹${(val / 100000).toFixed(2)} L`;
    }
    return `₹${val.toLocaleString('en-IN')}`;
  };

  return (
    <section id="roi" className="py-20 px-4 sm:px-6 max-w-5xl mx-auto border-t border-stone-200">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-14">
        <span className="text-xs font-bold text-stone-500 uppercase tracking-widest block mb-2">
          Pricing & Conversion Economics
        </span>
        <h2 className="text-3xl sm:text-5xl font-black text-[#141413] tracking-tight">
          ₹2 per check.{' '}
          <span className="font-editorial italic font-normal text-stone-600">
            Uncapped peer ROI.
          </span>
        </h2>
        <p className="mt-3 text-stone-600 text-sm sm:text-base max-w-xl mx-auto">
          Shoppers who discover mutual contacts are <strong>40% to 75% more likely to purchase</strong> than cold visitors. Calculate the direct revenue impact on your business.
        </p>
      </div>

      {/* Main Interactive Card */}
      <div className="bg-white rounded-3xl border border-stone-300/80 shadow-xl overflow-hidden">
        
        {/* Top Highlight Bar */}
        <div className="p-6 sm:p-8 bg-[#FAF9F5] border-b border-stone-200 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 font-bold text-xs mb-2">
              <span>Pay Strictly Per Value</span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl sm:text-5xl font-black text-[#141413]">₹2</span>
              <span className="text-sm font-semibold text-stone-600">/ successful mutual check</span>
            </div>
            <p className="text-xs text-stone-500 mt-1 max-w-md">
              Charged only when at least 1 contact (named or anonymous) is discovered in their mutual network.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 text-xs">
            <div className="p-3.5 rounded-xl bg-white border border-stone-200/90 shadow-sm">
              <span className="text-stone-500 block text-[11px] font-semibold uppercase">Zero Contacts Found:</span>
              <span className="font-bold text-emerald-700 text-base">₹0 (Free)</span>
            </div>
            <div className="p-3.5 rounded-xl bg-white border border-stone-200/90 shadow-sm">
              <span className="text-stone-500 block text-[11px] font-semibold uppercase">Setup & Monthly Fee:</span>
              <span className="font-bold text-stone-900 text-base">₹0 Forever</span>
            </div>
          </div>
        </div>

        {/* Sliders and ROI Visual Output */}
        <div className="p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Controls: Sliders */}
          <div className="lg:col-span-6 space-y-6">
            
            {/* Slider 1: Monthly Checks Scale (up to 50,000 checks!) */}
            <div>
              <div className="flex justify-between items-center text-xs font-bold text-stone-800 mb-2">
                <span>Monthly Shoppers Clicking Snippet</span>
                <span className="font-mono text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200 text-sm">
                  {monthlyChecks.toLocaleString('en-IN')} checks
                </span>
              </div>
              <input
                type="range"
                min={200}
                max={50000}
                step={200}
                value={monthlyChecks}
                onChange={(e) => setMonthlyChecks(Number(e.target.value))}
                className="w-full h-2 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-[#141413]"
              />
              <div className="flex justify-between text-[10px] text-stone-400 mt-1 font-mono">
                <span>200</span>
                <span>25,000</span>
                <span>50,000 checks</span>
              </div>
            </div>

            {/* Slider 2: Average Order Value / Ticket Size */}
            <div>
              <div className="flex justify-between items-center text-xs font-bold text-stone-800 mb-2">
                <span>Average Order Value / Ticket Size (AOV)</span>
                <span className="font-mono text-stone-900 bg-stone-100 px-2.5 py-1 rounded border border-stone-200 text-sm font-bold">
                  ₹{ticketSize.toLocaleString('en-IN')}
                </span>
              </div>
              <input
                type="range"
                min={400}
                max={25000}
                step={200}
                value={ticketSize}
                onChange={(e) => setTicketSize(Number(e.target.value))}
                className="w-full h-2 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-[#141413]"
              />
              <div className="flex justify-between text-[10px] text-stone-400 mt-1 font-mono">
                <span>₹400</span>
                <span>₹12,000</span>
                <span>₹25,000+</span>
              </div>
            </div>

            {/* Conversion Likelihood Toggle */}
            <div className="p-3.5 rounded-xl bg-[#FAF9F5] border border-stone-200 text-xs space-y-2">
              <div className="flex justify-between items-center font-bold text-stone-800">
                <span>Peer Trust Conversion Rate:</span>
                <span className="font-mono text-emerald-800 font-bold">{conversionLiftPct}% conversion</span>
              </div>
              <p className="text-[11px] text-stone-500">
                When a buyer sees a mutual friend using your product, purchase hesitation drops by over 70%.
              </p>
              <div className="flex gap-2 pt-1">
                {[35, 45, 60, 75].map((pct) => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => setConversionLiftPct(pct)}
                    className={`flex-1 py-1 rounded text-[11px] font-bold transition ${
                      conversionLiftPct === pct
                        ? 'bg-[#141413] text-white'
                        : 'bg-white text-stone-600 border border-stone-200'
                    }`}
                  >
                    {pct}%
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Right: The High-Scale ROI Box */}
          <div className="lg:col-span-6 bg-[#141413] text-white rounded-2xl p-6 sm:p-7 space-y-6 shadow-xl relative overflow-hidden">
            
            {/* Top Stat */}
            <div>
              <span className="text-[11px] font-mono tracking-wider uppercase text-emerald-400 block mb-1">
                Estimated Monthly Gross Revenue Added
              </span>
              <div className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-white">
                +{formatINR(incrementalRevenue)}
                <span className="text-xs font-sans font-normal text-stone-400 ml-1.5">/ month</span>
              </div>
              <div className="text-xs text-stone-400 mt-1">
                Approx. <strong>{formatINR(annualIncrementalRevenue)}</strong> in annualized extra GMV.
              </div>
            </div>

            {/* Breakdown List */}
            <div className="space-y-2.5 pt-4 border-t border-stone-800 text-xs">
              <div className="flex justify-between text-stone-300">
                <span>Extra Converted Customers:</span>
                <span className="font-mono font-bold text-emerald-400">
                  +{convertedBuyers.toLocaleString('en-IN')} buyers
                </span>
              </div>
              <div className="flex justify-between text-stone-300">
                <span>OG Network Cost (at ₹2/check):</span>
                <span className="font-mono font-bold text-stone-200">
                  ₹{ogCost.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="flex justify-between text-stone-300 pt-1 border-t border-stone-800">
                <span>Expected Return on Investment (ROI):</span>
                <span className="font-mono font-black text-emerald-400 text-sm">
                  {roiMultiple}x Return
                </span>
              </div>
            </div>

            {/* CTA inside */}
            <div className="pt-2">
              <button
                onClick={onOpenGetSnippet}
                className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Get Snippet for Your Store</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
