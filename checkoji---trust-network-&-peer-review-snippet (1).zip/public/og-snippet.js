/**
 * OG Peer Trust Snippet v1.0
 * Official embed script for OG (Mutual Contacts Trust Network)
 * (c) 2026 OG Inc. All rights reserved.
 * 
 * Usage:
 * <script src="https://cdn.ognetwork.io/snippet.js" data-og-id="YOUR_KEY" async></script>
 * <div id="og-trust-snippet" data-item-id="YOUR_PRODUCT_ID"></div>
 */
(function(window, document) {
  'use strict';

  function initOG() {
    var containers = document.querySelectorAll('#og-trust-snippet, [data-og-container]');
    if (!containers || containers.length === 0) return;

    containers.forEach(function(container) {
      if (container.getAttribute('data-og-rendered')) return;
      container.setAttribute('data-og-rendered', 'true');

      var itemId = container.getAttribute('data-item-id') || 'default-item';

      var badge = document.createElement('button');
      badge.type = 'button';
      badge.className = 'og-trigger-badge';
      badge.style.cssText = [
        'display: inline-flex',
        'align-items: center',
        'gap: 8px',
        'padding: 7px 14px',
        'border-radius: 9999px',
        'background: #FFFFFF',
        'color: #0F172A',
        'border: 1px solid #10B981',
        'font-size: 12px',
        'font-weight: 700',
        'font-family: system-ui, -apple-system, sans-serif',
        'cursor: pointer',
        'box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08)',
        'transition: all 0.2s ease'
      ].join(';');

      badge.innerHTML = [
        '<span style="display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:6px;background:#059669;color:#FFF;font-weight:900;font-size:10px;">OG</span>',
        '<span>See who in your contacts uses this</span>',
        '<span style="color:#059669;font-size:12px;">&rarr;</span>'
      ].join('');

      badge.onmouseover = function() {
        badge.style.background = '#F0FDF4';
      };
      badge.onmouseout = function() {
        badge.style.background = '#FFFFFF';
      };

      badge.onclick = function() {
        openOGDrawer(itemId);
      };

      container.appendChild(badge);
    });
  }

  function openOGDrawer(itemId) {
    var existing = document.getElementById('og-overlay-modal');
    if (existing) existing.remove();

    var overlay = document.createElement('div');
    overlay.id = 'og-overlay-modal';
    overlay.style.cssText = [
      'position: fixed',
      'inset: 0',
      'z-index: 999999',
      'display: flex',
      'align-items: center',
      'justify-content: center',
      'background: rgba(15, 23, 42, 0.6)',
      'backdrop-filter: blur(4px)',
      'font-family: system-ui, -apple-system, sans-serif'
    ].join(';');

    var dialog = document.createElement('div');
    dialog.style.cssText = [
      'width: 90%',
      'max-width: 420px',
      'background: #FFFFFF',
      'color: #0F172A',
      'border: 1px solid #E2E8F0',
      'border-radius: 18px',
      'padding: 20px',
      'box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.25)',
      'position: relative'
    ].join(';');

    dialog.innerHTML = [
      '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;border-bottom:1px solid #F1F5F9;padding-bottom:10px;">',
        '<div style="display:flex;align-items:center;gap:8px;">',
          '<span style="width:24px;height:24px;border-radius:6px;background:#059669;color:#FFF;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:11px;">OG</span>',
          '<strong style="font-size:13px;color:#0F172A;">Mutual Contact Network</strong>',
        '</div>',
        '<button id="og-close-btn" style="background:transparent;border:none;color:#64748B;cursor:pointer;font-size:18px;">&times;</button>',
      '</div>',
      '<div style="margin-bottom:14px;font-size:12px;color:#475569;">',
        '<strong>2 people in your mutual contacts use this:</strong>',
      '</div>',
      '<div style="display:flex;flex-direction:column;gap:8px;margin-bottom:16px;">',
        '<div style="padding:10px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;font-size:12px;">',
          '<div style="font-weight:bold;color:#0F172A;">Rohan Mehta <span style="font-weight:normal;color:#64748B;">(In your contacts)</span></div>',
          '<p style="margin:4px 0 0 0;color:#334155;font-style:italic;">"Super high quality build, using it daily."</p>',
        '</div>',
        '<div style="padding:10px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;font-size:12px;display:flex;justify-content:space-between;align-items:center;">',
          '<div>',
            '<div style="font-weight:bold;color:#0F172A;">Anonymous Contact</div>',
            '<div style="font-size:11px;color:#64748B;">Reviewer chose to stay anonymous</div>',
          '</div>',
          '<button style="font-size:11px;font-weight:bold;background:#ECFDF5;color:#065F46;border:1px solid #A7F3D0;padding:4px 8px;border-radius:6px;cursor:pointer;" onclick="alert(\'Request to unmask sent! They will receive a private prompt.\')">Ask to unmask</button>',
        '</div>',
      '</div>',
      '<div style="font-size:11px;color:#94A3B8;text-align:center;">',
        'Contacts matched only if saved in both phone books.',
      '</div>'
    ].join('');

    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    document.getElementById('og-close-btn').onclick = function() {
      overlay.remove();
    };
    overlay.onclick = function(e) {
      if (e.target === overlay) overlay.remove();
    };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initOG);
  } else {
    initOG();
  }

  window.OG = {
    init: initOG,
    open: openOGDrawer
  };

})(window, document);
